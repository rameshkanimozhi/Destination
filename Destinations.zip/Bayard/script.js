

/* ------------------ JS SLIDER ------------------ */
const slides = document.querySelectorAll(".slide");
const thumbs = document.querySelectorAll(".thumbs img");
const titleText = document.getElementById("titleText");
const regionText = document.getElementById("regionText");
const regionplace = document.getElementById("regionplace");
const descrip = document.getElementById("explain-details");

const slideData = [
    {
        title: "Americas",
        region: "Americas | Chile",
        description:"The Americas is a region marked by an astounding variety of landscapes and cultural experiences."
    },
    {
        title: "Chile Peaks",
        region: "Chile Peaks",
        description:"Chile’s major Andes peaks include Ojos del Salado, the world’s highest active volcano, and Torres del Paine’s iconic granite towers formed by glacial erosion."
    },
    {
        title: "Desert Canyon",
        region: "Desert Canyon",
        description:"A desert canyon is a narrow, steep-walled valley cut into arid rock landscapes by erosion."
    }
];

// total slides
const totalSlides = slides.length;

let index = 0;


/* ---------- Animated counter (UP direction) ---------- */
function updateCounter(i) {
    const current = String(i + 1).padStart(2, "0");
    const total = String(totalSlides).padStart(2, "0");

    // Add animation class
    regionText.classList.add("counter-anim");

    // Change number *after* animation starts
    setTimeout(() => {
        regionText.textContent = `${current}–${total}`;
    }, 120);

    // Remove class after animation finishes
    setTimeout(() => {
        regionText.classList.remove("counter-anim");
    }, 300);
}


/* -------------- Update Slide Function -------------- */
function goTo(i){
    slides.forEach(s => s.classList.remove("active"));
    thumbs.forEach(t => t.classList.remove("active"));

    slides[i].classList.add("active");
    thumbs[i].classList.add("active");

    // Update texts
    titleText.textContent = slideData[i].title;
    regionplace.textContent = slideData[i].region;
    descrip.textContent = slideData[i].description;

    // Update animated counter
    updateCounter(i);

    index = i;
}


/* ---------------- Auto Slide ---------------- */
function autoSlide(){
    index++;
    if(index >= slides.length) index = 0;
    goTo(index);
}

// initialize first
updateCounter(0);

setInterval(autoSlide, 4000);



const hamburgerBtn = document.getElementById("hamburgerBtn");
const mobileMenu = document.getElementById("mobileMenu");
const closeMenuBtn = document.getElementById("closeMenuBtn");

hamburgerBtn.addEventListener("click", () => {
    mobileMenu.classList.add("open");
});

closeMenuBtn.addEventListener("click", () => {
    mobileMenu.classList.remove("open");
});



window.addEventListener("load", () => {
    const preloader = document.getElementById("preloader");
    const main = document.getElementById("main-content");

    setTimeout(() => {
        preloader.classList.add("fade-out");
    }, 1500);

    setTimeout(() => {
        preloader.style.display = "none";
        main.style.display = "block";
    }, 2300);
});